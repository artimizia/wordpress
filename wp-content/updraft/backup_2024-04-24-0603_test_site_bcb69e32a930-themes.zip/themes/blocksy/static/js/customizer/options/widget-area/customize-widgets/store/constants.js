/**
 * Module Constants
 */
export const STORE_NAME = 'blocksy/core/customize-widgets'
