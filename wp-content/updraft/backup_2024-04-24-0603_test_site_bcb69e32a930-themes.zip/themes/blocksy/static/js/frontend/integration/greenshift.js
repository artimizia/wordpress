export const mountGreenshiftIntegration = () => {
	if (window.gsInitTabs) {
		window.gsInitTabs('.gspb-tabs')
	}
}
