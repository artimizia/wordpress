<?php

$config = [
	'name' => __('Socials', 'blocksy'),
	'clone' => true,

	'selective_refresh' => [
		'header_socials',
		'headerSocialsColor'
	],
];

