<?php

$config = [
	'name' => __('Menu', 'blocksy'),
	'typography_keys' => ['footerMenuFont'],
	'selective_refresh' => ['menu']
];

