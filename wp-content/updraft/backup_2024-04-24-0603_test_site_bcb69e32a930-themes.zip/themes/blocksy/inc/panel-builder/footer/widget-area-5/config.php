<?php

$config = [
	'name' => __('Widget Area 5', 'blocksy')
];



